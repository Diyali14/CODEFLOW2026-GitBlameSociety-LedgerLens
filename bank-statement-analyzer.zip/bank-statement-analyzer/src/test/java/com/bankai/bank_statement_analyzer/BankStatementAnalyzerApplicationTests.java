package com.bankai.bank_statement_analyzer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankStatementAnalyzerApplicationTests {

	@Test
	void contextLoads() {
	}

}
